require('dotenv').config();
const { query, pool } = require('../src/db');

const migrations = [
  /* ── 1. Users (agents + admins) ───────────────────────── */
  `CREATE TABLE IF NOT EXISTS users (
    id          SERIAL PRIMARY KEY,
    username    VARCHAR(50)  UNIQUE NOT NULL,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) UNIQUE,
    password    VARCHAR(255) NOT NULL,
    role        VARCHAR(20)  NOT NULL DEFAULT 'agent'
                  CHECK (role IN ('admin','agent')),
    is_active   BOOLEAN      NOT NULL DEFAULT true,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
  )`,

  /* ── 2. Leads ──────────────────────────────────────────── */
  `CREATE TABLE IF NOT EXISTS leads (
    id           SERIAL PRIMARY KEY,
    name         VARCHAR(150) NOT NULL,
    phone        VARCHAR(20)  NOT NULL,
    email        VARCHAR(150),
    course       VARCHAR(150),
    industry     VARCHAR(50)  NOT NULL DEFAULT 'Education'
                   CHECK (industry IN ('Education','Real Estate','Sales / B2C','Other')),
    source       VARCHAR(80)  NOT NULL DEFAULT 'Walk-in',
    status       VARCHAR(30)  NOT NULL DEFAULT 'New'
                   CHECK (status IN ('New','Contacted','Interested','Enrolled','Lost')),
    priority     VARCHAR(20)  NOT NULL DEFAULT 'Normal'
                   CHECK (priority IN ('Hot','Normal','Cold')),
    assigned_to  INTEGER      REFERENCES users(id) ON DELETE SET NULL,
    created_by   INTEGER      REFERENCES users(id) ON DELETE SET NULL,
    followup_at  DATE,
    followup_note VARCHAR(500),
    fee_total    NUMERIC(12,2) NOT NULL DEFAULT 0,
    fee_paid     NUMERIC(12,2) NOT NULL DEFAULT 0,
    fee_due_date DATE,
    fee_status   VARCHAR(30)  NOT NULL DEFAULT 'Not started'
                   CHECK (fee_status IN ('Not started','Pending','Partial','Paid','N/A')),
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
  )`,

  /* ── 3. Call logs ─────────────────────────────────────── */
  `CREATE TABLE IF NOT EXISTS call_logs (
    id           SERIAL PRIMARY KEY,
    lead_id      INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    logged_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    call_type    VARCHAR(30) NOT NULL DEFAULT 'Outbound'
                   CHECK (call_type IN ('Outbound','Inbound','WhatsApp call')),
    disposition  VARCHAR(50) NOT NULL,
    duration     VARCHAR(30),
    remark       TEXT,
    followup_at  DATE,
    followup_note VARCHAR(500),
    called_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`,

  /* ── 4. Notes ─────────────────────────────────────────── */
  `CREATE TABLE IF NOT EXISTS notes (
    id         SERIAL PRIMARY KEY,
    lead_id    INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    author_id  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    body       TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`,

  /* ── 5. WhatsApp messages ─────────────────────────────── */
  `CREATE TABLE IF NOT EXISTS whatsapp_messages (
    id          SERIAL PRIMARY KEY,
    lead_id     INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    sent_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    direction   VARCHAR(5) NOT NULL CHECK (direction IN ('in','out')),
    body        TEXT NOT NULL,
    status      VARCHAR(20) NOT NULL DEFAULT 'sent',
    sent_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`,

  /* ── 6. Fee payments ──────────────────────────────────── */
  `CREATE TABLE IF NOT EXISTS fee_payments (
    id           SERIAL PRIMARY KEY,
    lead_id      INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    recorded_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    amount       NUMERIC(12,2) NOT NULL,
    payment_mode VARCHAR(50) NOT NULL DEFAULT 'Cash',
    note         TEXT,
    paid_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`,

  /* ── 7. Auto-update updated_at ────────────────────────── */
  `CREATE OR REPLACE FUNCTION set_updated_at()
   RETURNS TRIGGER AS $$
   BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
   $$ LANGUAGE plpgsql`,

  `DO $$ BEGIN
     IF NOT EXISTS (
       SELECT 1 FROM pg_trigger WHERE tgname = 'trg_leads_updated_at'
     ) THEN
       CREATE TRIGGER trg_leads_updated_at
       BEFORE UPDATE ON leads
       FOR EACH ROW EXECUTE FUNCTION set_updated_at();
     END IF;
   END $$`,

  `DO $$ BEGIN
     IF NOT EXISTS (
       SELECT 1 FROM pg_trigger WHERE tgname = 'trg_users_updated_at'
     ) THEN
       CREATE TRIGGER trg_users_updated_at
       BEFORE UPDATE ON users
       FOR EACH ROW EXECUTE FUNCTION set_updated_at();
     END IF;
   END $$`,

  /* ── 8. Indexes ───────────────────────────────────────── */
  `CREATE INDEX IF NOT EXISTS idx_leads_assigned_to  ON leads(assigned_to)`,
  `CREATE INDEX IF NOT EXISTS idx_leads_status        ON leads(status)`,
  `CREATE INDEX IF NOT EXISTS idx_leads_followup_at   ON leads(followup_at)`,
  `CREATE INDEX IF NOT EXISTS idx_call_logs_lead_id   ON call_logs(lead_id)`,
  `CREATE INDEX IF NOT EXISTS idx_notes_lead_id        ON notes(lead_id)`,
  `CREATE INDEX IF NOT EXISTS idx_wa_lead_id           ON whatsapp_messages(lead_id)`,
  `CREATE INDEX IF NOT EXISTS idx_fee_payments_lead_id ON fee_payments(lead_id)`,
];

async function migrate() {
  console.log('▶  Running migrations…');
  for (const sql of migrations) {
    await query(sql);
  }
  console.log('✅  All tables ready.');
  await pool.end();
}

migrate().catch((err) => {
  console.error('Migration failed:', err);
  process.exit(1);
});
