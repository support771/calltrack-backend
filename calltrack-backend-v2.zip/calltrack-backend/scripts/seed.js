require('dotenv').config();
const bcrypt = require('bcryptjs');
const { query, pool } = require('../src/db');

async function seed() {
  console.log('▶  Seeding demo data…');

  /* ── Users ── */
  const hash = (pw) => bcrypt.hashSync(pw, 10);

  const users = await query(`
    INSERT INTO users (username, name, email, password, role) VALUES
      ('admin', 'Admin',       'admin@calltrack.in', $1, 'admin'),
      ('priya', 'Priya Sharma','priya@calltrack.in', $2, 'agent'),
      ('raj',   'Raj Verma',   'raj@calltrack.in',   $3, 'agent')
    ON CONFLICT (username) DO UPDATE SET name = EXCLUDED.name
    RETURNING id, username
  `, [hash('admin@123'), hash('agent@123'), hash('agent@123')]);

  const byUsername = {};
  users.rows.forEach((u) => { byUsername[u.username] = u.id; });
  const adminId = byUsername['admin'];
  const priyaId = byUsername['priya'];
  const rajId   = byUsername['raj'];

  /* ── Leads ── */
  const leadRows = await query(`
    INSERT INTO leads
      (name, phone, email, course, industry, source, status, priority,
       assigned_to, created_by, followup_at, followup_note,
       fee_total, fee_paid, fee_status)
    VALUES
      ('Arjun Mehta',  '+91 98765 43210', 'arjun@example.com',  'MBA',            'Education',    'Walk-in',      'Interested', 'Hot',    $1, $2, NOW()+INTERVAL '3d', 'Call about fee structure',    85000,  0,      'Pending'),
      ('Sneha Rao',    '+91 91234 56789', 'sneha@example.com',  'B.Tech CSE',     'Education',    'Website',      'Enrolled',   'Normal', $1, $2, NOW()+INTERVAL '6d', 'Send joining kit',           120000, 120000, 'Paid'),
      ('Karan Patel',  '+91 87654 32109', NULL,                 'B.Com',          'Education',    'Referral',     'Contacted',  'Normal', $1, $2, NOW()-INTERVAL '1d', 'Send document checklist',     45000,  0,      'Not started'),
      ('Divya Nair',   '+91 99887 76655', NULL,                 'MBA',            'Education',    'Social media', 'New',        'Normal', $1, $2, NOW(),               'Initial call',                85000,  0,      'Not started'),
      ('Rahul Sharma', '+91 88990 01122', NULL,                 'B.Tech Mech',    'Education',    'Cold call',    'Lost',       'Cold',   $1, $2, NULL,                NULL,                               0,  0,      'N/A'),
      ('Pooja Iyer',   '+91 77665 54433', NULL,                 'BBA',            'Education',    'Walk-in',      'Interested', 'Hot',    $3, $2, NOW()+INTERVAL '5d', 'Send scholarship form',       55000,  0,      'Pending'),
      ('Manoj Verma',  '+91 98001 23456', NULL,                 '3BHK Flat',      'Real Estate',  '99acres',      'Interested', 'Hot',    $3, $2, NOW()+INTERVAL '4d', 'Site visit confirmation',   7500000, 100000, 'Partial'),
      ('Anita Desai',  '+91 91111 22333', NULL,                 '2BHK Flat',      'Real Estate',  'MagicBricks',  'Contacted',  'Normal', $4, $2, NOW()+INTERVAL '3d', 'Send floor plan',           4800000,  0,      'Not started'),
      ('Vikram Singh', '+91 99555 66777', NULL,                 'Health Insurance','Sales / B2C', 'Cold call',    'New',        'Normal', $3, $2, NOW()+INTERVAL '2d', 'Initial pitch call',               0,  0,      'N/A'),
      ('Meera Joshi',  '+91 88444 55666', NULL,                 'Term Insurance', 'Sales / B2C',  'Referral',     'Enrolled',   'Normal', $1, $2, NULL,                NULL,                           15000, 15000,  'Paid')
    ON CONFLICT DO NOTHING
    RETURNING id, name
  `, [priyaId, adminId, rajId, adminId]);

  const leadIds = leadRows.rows.map((r) => r.id);
  if (!leadIds.length) {
    console.log('ℹ  Leads already seeded. Skipping call/note seeds.');
    await pool.end();
    return;
  }

  const [arjun, sneha, karan, , rahul, pooja, manoj, anita, , meera] = leadIds;

  /* ── Call logs ── */
  await query(`
    INSERT INTO call_logs (lead_id, logged_by, call_type, disposition, duration, remark, called_at) VALUES
      ($1,  $2, 'Outbound',      'Interested',    '8 min',  'Very keen on MBA. Needs scholarship info.',   NOW()-INTERVAL '7d'),
      ($1,  $2, 'WhatsApp call', 'Follow-up',     '4 min',  'Sent brochure over WhatsApp.',                NOW()-INTERVAL '13d'),
      ($3,  $2, 'Inbound',       'Enrolled',      '12 min', 'Confirmed enrollment. Fees paid.',            NOW()-INTERVAL '20d'),
      ($3,  $2, 'Outbound',      'Interested',    '6 min',  'All queries answered.',                       NOW()-INTERVAL '30d'),
      ($4,  $2, 'Outbound',      'Callback',      '5 min',  'Will discuss with parents. Call back Sat.',  NOW()-INTERVAL '11d'),
      ($5,  $2, 'Outbound',      'Not interested','7 min',  'Joined another college.',                     NOW()-INTERVAL '35d'),
      ($6,  $7, 'Outbound',      'Interested',    '9 min',  'Wants scholarship. 87% score in 12th.',       NOW()-INTERVAL '10d'),
      ($8,  $7, 'Outbound',      'Interested',    '15 min', 'Very interested. Site visit scheduled.',      NOW()-INTERVAL '5d'),
      ($9,  $2, 'Inbound',       'Follow-up',     '8 min',  'Needs floor plan and bank loan details.',     NOW()-INTERVAL '4d'),
      ($10, $2, 'Outbound',      'Enrolled',      '20 min', 'Policy issued. Premium collected.',           NOW()-INTERVAL '15d')
  `, [arjun, priyaId, sneha, karan, rahul, pooja, rajId, manoj, anita, meera]);

  /* ── Notes ── */
  await query(`
    INSERT INTO notes (lead_id, author_id, body) VALUES
      ($1, $2, '3 years work experience. Interested in weekend batch. Follow up on scholarship eligibility.'),
      ($1, $2, 'Walked in via referral from Rahul Sharma. Very motivated.'),
      ($3, $2, 'Full fees paid. Needs hostel accommodation details.'),
      ($4, $5, 'Merit student — score 87%. Eligible for partial scholarship.'),
      ($6, $5, 'Budget ₹75L, prefers east-facing flat. Token amount paid.')
  `, [arjun, priyaId, sneha, pooja, rajId, manoj]);

  /* ── WhatsApp messages ── */
  await query(`
    INSERT INTO whatsapp_messages (lead_id, sent_by, direction, body, sent_at) VALUES
      ($1, $2, 'out', 'Hi Arjun! Thanks for visiting us. We have an excellent MBA program. Shall I share the details?', NOW()-INTERVAL '13d'),
      ($1, NULL,'in',  'Yes please, send me the brochure.',                                                              NOW()-INTERVAL '13d'+INTERVAL '5min'),
      ($1, $2, 'out', 'Brochure sent! Feel free to call us anytime.',                                                   NOW()-INTERVAL '13d'+INTERVAL '6min'),
      ($3, $4, 'out', 'Hi Manoj! We have excellent 3BHK units available from ₹65L. Interested?',                        NOW()-INTERVAL '7d'),
      ($3, NULL,'in',  'Yes, what are the amenities?',                                                                   NOW()-INTERVAL '7d'+INTERVAL '15min'),
      ($3, $4, 'out', 'Swimming pool, gym, 24hr security, 2 covered parking. Shall we schedule a visit?',               NOW()-INTERVAL '7d'+INTERVAL '20min')
  `, [arjun, priyaId, manoj, rajId]);

  /* ── Fee payments ── */
  await query(`
    INSERT INTO fee_payments (lead_id, recorded_by, amount, payment_mode, note, paid_at) VALUES
      ($1, $2, 120000, 'Online transfer', 'Full fees — B.Tech CSE',      NOW()-INTERVAL '20d'),
      ($3, $4, 100000, 'Cheque',          'Token amount — 3BHK Flat',    NOW()-INTERVAL '5d'),
      ($5, $2, 15000,  'UPI',             'Term Insurance premium',       NOW()-INTERVAL '15d')
  `, [sneha, priyaId, manoj, rajId, meera]);

  console.log('✅  Seed complete.');
  await pool.end();
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
