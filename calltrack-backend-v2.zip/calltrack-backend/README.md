# CallTrack CRM — Backend API

Node.js · Express · PostgreSQL · Railway

---

## Project structure

```
calltrack-backend/
├── src/
│   ├── index.js              # Express app + server
│   ├── db/index.js           # PostgreSQL connection pool
│   ├── middleware/
│   │   ├── auth.js           # JWT authenticate + requireAdmin
│   │   └── errors.js         # asyncHandler, validate, errorHandler
│   └── routes/
│       ├── auth.js           # POST /login, GET /me, POST /change-password
│       ├── leads.js          # Full CRUD + calls, notes, WhatsApp, payments
│       ├── users.js          # Agent management
│       └── reports.js        # Analytics, follow-ups, fees
├── scripts/
│   ├── migrate.js            # Creates all tables + indexes
│   └── seed.js               # Demo users + 10 sample leads
├── railway.toml
├── .env.example
└── package.json
```

---

## Local setup

```bash
# 1. Install dependencies
npm install

# 2. Copy env file and fill in values
cp .env.example .env

# 3. Create tables
npm run db:migrate

# 4. Load demo data
npm run db:seed

# 5. Start dev server (auto-restarts on save)
npm run dev
```

The API will be at **http://localhost:3000**.

---

## Deploy to Railway

### Step 1 — Push to GitHub
```bash
git init
git add .
git commit -m "initial backend"
git remote add origin https://github.com/YOUR_USERNAME/calltrack-backend.git
git push -u origin main
```

### Step 2 — Create Railway project
1. Go to [railway.app](https://railway.app) → New project → Deploy from GitHub repo
2. Select your repo

### Step 3 — Add PostgreSQL
1. In your Railway project → **+ New** → **Database** → **PostgreSQL**
2. Railway auto-sets `DATABASE_URL` in your service's environment

### Step 4 — Set environment variables
In Railway → your service → **Variables**, add:
```
JWT_SECRET=<generate with: openssl rand -hex 32>
JWT_EXPIRES_IN=7d
NODE_ENV=production
ALLOWED_ORIGINS=https://your-frontend.railway.app
```

### Step 5 — Run migrations on Railway
In Railway → your service → **Shell**:
```bash
npm run db:migrate
npm run db:seed
```

Your API is live at the Railway-provided URL (e.g. `https://calltrack-api.railway.app`).

---

## API reference

All protected routes require:
```
Authorization: Bearer <token>
```

### Auth
| Method | Path | Body | Description |
|--------|------|------|-------------|
| POST | `/api/auth/login` | `{username, password}` | Returns JWT token |
| GET  | `/api/auth/me`    | — | Current user info |
| POST | `/api/auth/change-password` | `{current_password, new_password}` | Change password |

### Leads
| Method | Path | Description |
|--------|------|-------------|
| GET    | `/api/leads` | List leads (filterable: `status`, `priority`, `industry`, `search`, `overdue`, `page`, `limit`) |
| GET    | `/api/leads/stats` | Dashboard summary — pipeline counts, fees, overdue |
| GET    | `/api/leads/:id` | Single lead with calls, notes, WhatsApp, payments |
| POST   | `/api/leads` | Create lead |
| PATCH  | `/api/leads/:id` | Update any field |
| DELETE | `/api/leads/:id` | Delete (admin only) |
| POST   | `/api/leads/:id/calls` | Log a call (auto-updates lead status) |
| POST   | `/api/leads/:id/notes` | Add a note |
| POST   | `/api/leads/:id/whatsapp` | Save a WhatsApp message |
| POST   | `/api/leads/:id/payments` | Record a fee payment (auto-updates fee_paid) |

### Users
| Method | Path | Description |
|--------|------|-------------|
| GET    | `/api/users` | List agents (admin sees all, agent sees self) |
| GET    | `/api/users/:id/stats` | Agent performance stats (admin only) |
| POST   | `/api/users` | Create agent (admin only) |
| PATCH  | `/api/users/:id` | Update user |

### Reports (admin only)
| Method | Path | Description |
|--------|------|-------------|
| GET    | `/api/reports/overview` | Pipeline, sources, agents, fees, call dispositions |
| GET    | `/api/reports/followups` | Overdue, today, upcoming follow-ups |
| GET    | `/api/reports/fees` | Fee collection per lead with payment history |

---

## Demo credentials

| Role  | Username | Password   |
|-------|----------|------------|
| Admin | admin    | admin@123  |
| Agent | priya    | agent@123  |
| Agent | raj      | agent@123  |

---

## Connecting the frontend

Replace the hardcoded `leads` array in `index.html` with API calls:

```javascript
const API = 'https://your-api.railway.app';
let token = localStorage.getItem('ct_token');

// Login
const { token: t, user } = await fetch(`${API}/api/auth/login`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ username, password })
}).then(r => r.json());
localStorage.setItem('ct_token', t);

// Fetch leads
const { data } = await fetch(`${API}/api/leads?status=Interested&page=1`, {
  headers: { Authorization: `Bearer ${token}` }
}).then(r => r.json());

// Log a call
await fetch(`${API}/api/leads/1/calls`, {
  method: 'POST',
  headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
  body: JSON.stringify({ disposition: 'Interested', call_type: 'Outbound', remark: 'Very keen' })
});
```
