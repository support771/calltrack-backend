require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const { errorHandler } = require('./middleware/errors');

const app = express();

/* ── CORS ── */
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '')
  .split(',').map((o) => o.trim()).filter(Boolean);

app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
      cb(null, true);
    } else {
      cb(new Error(`CORS: origin ${origin} not allowed`));
    }
  },
  credentials: true,
}));

/* ── Body parsing ── */
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

/* ── Health check ── */
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

/* ── API routes ── */
app.use('/api/auth',    require('./routes/auth'));
app.use('/api/leads',   require('./routes/leads'));
app.use('/api/users',   require('./routes/users'));
app.use('/api/reports', require('./routes/reports'));

/* ── 404 ── */
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.path} not found` });
});

/* ── Global error handler ── */
app.use(errorHandler);

/* ── Start ── */
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅  CallTrack API running on port ${PORT} [${process.env.NODE_ENV || 'development'}]`);
});

module.exports = app;
