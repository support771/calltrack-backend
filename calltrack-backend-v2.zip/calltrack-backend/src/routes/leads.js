const router  = require('express').Router();
const { body, query: qv, param } = require('express-validator');
const db      = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { asyncHandler, validate }     = require('../middleware/errors');

router.use(authenticate);

/* ── Shared SELECT fragment ────────────────────────────────── */
const LEAD_SELECT = `
  l.id, l.name, l.phone, l.email, l.course, l.industry, l.source,
  l.status, l.priority, l.followup_at, l.followup_note,
  l.fee_total, l.fee_paid, l.fee_due_date, l.fee_status,
  l.created_at, l.updated_at,
  u.id   AS agent_id,   u.name   AS agent_name,   u.username AS agent_username,
  cu.id  AS created_by_id, cu.name AS created_by_name
  FROM leads l
  LEFT JOIN users u  ON u.id  = l.assigned_to
  LEFT JOIN users cu ON cu.id = l.created_by
`;

/* ── GET /api/leads ────────────────────────────────────────
   FIX: agentFilter no longer injects user.id into raw SQL.
   All dynamic filters go through parameterised $N placeholders.
────────────────────────────────────────────────────────── */
router.get(
  '/',
  [
    qv('page').optional().isInt({ min: 1 }),
    qv('limit').optional().isInt({ min: 1, max: 200 }),
    qv('sort').optional().isIn(['created_at','updated_at','name','status','followup_at','priority']),
    qv('order').optional().isIn(['asc','desc']),
    qv('overdue').optional().isBoolean(),
    qv('followup_date').optional().isDate(),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const {
      status, priority, industry, agent_id,
      search, sort = 'created_at', order = 'desc',
      page = 1, limit = 50,
      overdue, followup_date,
    } = req.query;

    const values      = [];
    const conditions  = [];

    // FIX: user.id goes through parameterised placeholder
    if (req.user.role !== 'admin') {
      values.push(req.user.id);
      conditions.push(`l.assigned_to = $${values.length}`);
    }
    if (status) {
      values.push(status);
      conditions.push(`l.status = $${values.length}`);
    }
    if (priority) {
      values.push(priority);
      conditions.push(`l.priority = $${values.length}`);
    }
    if (industry) {
      values.push(industry);
      conditions.push(`l.industry = $${values.length}`);
    }
    if (agent_id && req.user.role === 'admin') {
      values.push(parseInt(agent_id, 10));
      conditions.push(`l.assigned_to = $${values.length}`);
    }
    if (followup_date) {
      values.push(followup_date);
      conditions.push(`l.followup_at = $${values.length}`);
    }
    if (overdue === 'true') {
      conditions.push(`l.followup_at < CURRENT_DATE AND l.followup_at IS NOT NULL`);
    }
    if (search) {
      values.push(`%${search}%`);
      const n = values.length;
      conditions.push(`(l.name ILIKE $${n} OR l.phone ILIKE $${n} OR l.course ILIKE $${n} OR l.email ILIKE $${n})`);
    }

    const where   = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const sortDir = order === 'asc' ? 'ASC' : 'DESC';
    const offset  = (Math.max(1, parseInt(page)) - 1) * parseInt(limit);

    // pagination params added last
    const dataValues  = [...values, parseInt(limit), offset];
    const countValues = [...values];

    const [dataRes, countRes] = await Promise.all([
      db.query(
        `SELECT ${LEAD_SELECT} ${where}
         ORDER BY l.${sort} ${sortDir}
         LIMIT $${dataValues.length - 1} OFFSET $${dataValues.length}`,
        dataValues
      ),
      db.query(`SELECT COUNT(*) FROM leads l ${where}`, countValues),
    ]);

    res.json({
      data:  dataRes.rows,
      total: parseInt(countRes.rows[0].count),
      page:  parseInt(page),
      limit: parseInt(limit),
    });
  })
);

/* ── GET /api/leads/stats ──────────────────────────────────
   FIX: user.id in parameterised placeholder, not raw SQL.
────────────────────────────────────────────────────────── */
router.get('/stats', asyncHandler(async (req, res) => {
  const isAdmin  = req.user.role === 'admin';
  const params   = isAdmin ? [] : [req.user.id];
  const agentWhere = isAdmin ? '' : `AND l.assigned_to = $1`;
  const clWhere    = isAdmin ? '' : `AND cl.logged_by   = $1`;

  const [pipeline, fees, overdue, todayFu, totalCalls] = await Promise.all([
    db.query(`SELECT status, COUNT(*) AS count FROM leads l WHERE 1=1 ${agentWhere} GROUP BY status`, params),
    db.query(`SELECT SUM(fee_total) AS total, SUM(fee_paid) AS paid FROM leads l WHERE 1=1 ${agentWhere}`, params),
    db.query(`SELECT COUNT(*) FROM leads l WHERE followup_at < CURRENT_DATE AND followup_at IS NOT NULL ${agentWhere}`, params),
    db.query(`SELECT COUNT(*) FROM leads l WHERE followup_at = CURRENT_DATE ${agentWhere}`, params),
    db.query(`SELECT COUNT(*) FROM call_logs cl JOIN leads l ON l.id = cl.lead_id WHERE cl.called_at::date = CURRENT_DATE ${clWhere}`, params),
  ]);

  const pipelineMap = {};
  pipeline.rows.forEach(r => { pipelineMap[r.status] = parseInt(r.count); });

  res.json({
    pipeline:          pipelineMap,
    total_leads:       Object.values(pipelineMap).reduce((a, b) => a + b, 0),
    fees: {
      total: parseFloat(fees.rows[0].total) || 0,
      paid:  parseFloat(fees.rows[0].paid)  || 0,
    },
    overdue_followups: parseInt(overdue.rows[0].count),
    today_followups:   parseInt(todayFu.rows[0].count),
    calls_today:       parseInt(totalCalls.rows[0].count),
  });
}));

/* ── GET /api/leads/:id ────────────────────────────────────── */
router.get(
  '/:id',
  param('id').isInt(),
  validate,
  asyncHandler(async (req, res) => {
    const result = await db.query(`SELECT ${LEAD_SELECT} WHERE l.id = $1`, [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Lead not found' });

    const lead = result.rows[0];
    if (req.user.role !== 'admin' && lead.agent_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const [calls, notes, wa, payments] = await Promise.all([
      db.query(
        `SELECT cl.*, u.name AS logged_by_name
         FROM call_logs cl LEFT JOIN users u ON u.id = cl.logged_by
         WHERE cl.lead_id = $1 ORDER BY cl.called_at DESC`,
        [lead.id]
      ),
      db.query(
        `SELECT n.*, u.name AS author_name
         FROM notes n LEFT JOIN users u ON u.id = n.author_id
         WHERE n.lead_id = $1 ORDER BY n.created_at DESC`,
        [lead.id]
      ),
      db.query(
        `SELECT wm.*, u.name AS sent_by_name
         FROM whatsapp_messages wm LEFT JOIN users u ON u.id = wm.sent_by
         WHERE wm.lead_id = $1 ORDER BY wm.sent_at ASC`,
        [lead.id]
      ),
      db.query(
        `SELECT fp.*, u.name AS recorded_by_name
         FROM fee_payments fp LEFT JOIN users u ON u.id = fp.recorded_by
         WHERE fp.lead_id = $1 ORDER BY fp.paid_at DESC`,
        [lead.id]
      ),
    ]);

    res.json({
      ...lead,
      calls:    calls.rows,
      notes:    notes.rows,
      whatsapp: wa.rows,
      payments: payments.rows,
    });
  })
);

/* ── POST /api/leads ───────────────────────────────────────── */
router.post(
  '/',
  [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('phone').trim().notEmpty().withMessage('Phone is required'),
    body('email').optional({ checkFalsy: true }).isEmail(),
    body('industry').optional().isIn(['Education','Real Estate','Sales / B2C','Other']),
    body('status').optional().isIn(['New','Contacted','Interested','Enrolled','Lost']),
    body('priority').optional().isIn(['Hot','Normal','Cold']),
    body('fee_total').optional().isFloat({ min: 0 }),
    body('assigned_to').optional({ checkFalsy: true }).isInt(),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const {
      name, phone, email, course,
      industry  = 'Education',
      source    = 'Walk-in',
      status    = 'New',
      priority  = 'Normal',
      assigned_to,
      followup_at, followup_note,
      fee_total = 0, fee_due_date,
    } = req.body;

    const agentId = req.user.role === 'admin' && assigned_to
      ? parseInt(assigned_to, 10)
      : req.user.id;

    const result = await db.query(
      `INSERT INTO leads
         (name, phone, email, course, industry, source, status, priority,
          assigned_to, created_by, followup_at, followup_note, fee_total, fee_due_date)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
       RETURNING *`,
      [name, phone, email || null, course || null,
       industry, source, status, priority,
       agentId, req.user.id,
       followup_at || null, followup_note || null,
       parseFloat(fee_total), fee_due_date || null]
    );
    res.status(201).json(result.rows[0]);
  })
);

/* ── PATCH /api/leads/:id ──────────────────────────────────── */
router.patch(
  '/:id',
  param('id').isInt(),
  [
    body('email').optional({ checkFalsy: true }).isEmail(),
    body('industry').optional().isIn(['Education','Real Estate','Sales / B2C','Other']),
    body('status').optional().isIn(['New','Contacted','Interested','Enrolled','Lost']),
    body('priority').optional().isIn(['Hot','Normal','Cold']),
    body('fee_status').optional().isIn(['Not started','Pending','Partial','Paid','N/A']),
    body('fee_total').optional().isFloat({ min: 0 }),
    body('assigned_to').optional({ checkFalsy: true }).isInt(),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const existing = await db.query(`SELECT * FROM leads WHERE id = $1`, [id]);
    if (!existing.rows[0]) return res.status(404).json({ error: 'Lead not found' });
    if (req.user.role !== 'admin' && existing.rows[0].assigned_to !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const ALLOWED = [
      'name','phone','email','course','industry','source','status','priority',
      'assigned_to','followup_at','followup_note',
      'fee_total','fee_due_date','fee_status',
    ];

    const updates = [];
    const values  = [];
    ALLOWED.forEach(field => {
      if (req.body[field] !== undefined) {
        values.push(req.body[field] === '' ? null : req.body[field]);
        updates.push(`${field} = $${values.length}`);
      }
    });

    if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });
    values.push(id);

    const result = await db.query(
      `UPDATE leads SET ${updates.join(', ')} WHERE id = $${values.length} RETURNING *`,
      values
    );
    res.json(result.rows[0]);
  })
);

/* ── DELETE /api/leads/:id (admin only) ────────────────────── */
router.delete(
  '/:id',
  requireAdmin,
  param('id').isInt(),
  validate,
  asyncHandler(async (req, res) => {
    const { rowCount } = await db.query(`DELETE FROM leads WHERE id = $1`, [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: 'Lead not found' });
    res.json({ message: 'Lead deleted' });
  })
);

/* ── POST /api/leads/:id/calls ────────────────────────────────
   FIX: status update now fully parameterised — no more
   raw string builds like `status = '${newStatus}'`.
────────────────────────────────────────────────────────── */
router.post(
  '/:id/calls',
  param('id').isInt(),
  [
    body('disposition').trim().notEmpty().withMessage('Disposition is required'),
    body('call_type').optional().isIn(['Outbound','Inbound','WhatsApp call']),
    body('followup_at').optional({ checkFalsy: true }).isDate(),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const {
      call_type = 'Outbound',
      disposition,
      duration,
      remark,
      followup_at,
      followup_note,
    } = req.body;

    const lead = await db.query(`SELECT * FROM leads WHERE id = $1`, [id]);
    if (!lead.rows[0]) return res.status(404).json({ error: 'Lead not found' });
    if (req.user.role !== 'admin' && lead.rows[0].assigned_to !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // 1. Insert call log
    const callResult = await db.query(
      `INSERT INTO call_logs
         (lead_id, logged_by, call_type, disposition, duration, remark, followup_at, followup_note)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [id, req.user.id, call_type, disposition,
       duration || null, remark || null,
       followup_at || null, followup_note || null]
    );

    // 2. Derive new status — all via parameterised UPDATE
    const STATUS_MAP = {
      Interested:      'Interested',
      Enrolled:        'Enrolled',
      'Not interested':'Lost',
      Lost:            'Lost',
    };
    const newStatus = STATUS_MAP[disposition] ||
      (lead.rows[0].status === 'New' ? 'Contacted' : null);

    const leadUpdates = [];
    const leadValues  = [];

    if (newStatus) {
      leadValues.push(newStatus);
      leadUpdates.push(`status = $${leadValues.length}`);
    }
    if (followup_at) {
      leadValues.push(followup_at);
      leadUpdates.push(`followup_at = $${leadValues.length}`);
      leadValues.push(followup_note || null);
      leadUpdates.push(`followup_note = $${leadValues.length}`);
    }

    if (leadUpdates.length) {
      leadValues.push(id);
      await db.query(
        `UPDATE leads SET ${leadUpdates.join(', ')} WHERE id = $${leadValues.length}`,
        leadValues
      );
    }

    res.status(201).json(callResult.rows[0]);
  })
);

/* ── POST /api/leads/:id/notes ─────────────────────────────── */
router.post(
  '/:id/notes',
  param('id').isInt(),
  body('body').trim().notEmpty().withMessage('Note body is required'),
  validate,
  asyncHandler(async (req, res) => {
    const lead = await db.query(`SELECT id, assigned_to FROM leads WHERE id = $1`, [req.params.id]);
    if (!lead.rows[0]) return res.status(404).json({ error: 'Lead not found' });
    if (req.user.role !== 'admin' && lead.rows[0].assigned_to !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }
    const result = await db.query(
      `INSERT INTO notes (lead_id, author_id, body) VALUES ($1,$2,$3) RETURNING *`,
      [req.params.id, req.user.id, req.body.body]
    );
    res.status(201).json(result.rows[0]);
  })
);

/* ── POST /api/leads/:id/whatsapp ──────────────────────────── */
router.post(
  '/:id/whatsapp',
  param('id').isInt(),
  [
    body('body').trim().notEmpty().withMessage('Message body is required'),
    body('direction').optional().isIn(['in','out']),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const { body: msg, direction = 'out' } = req.body;
    const lead = await db.query(`SELECT id FROM leads WHERE id = $1`, [req.params.id]);
    if (!lead.rows[0]) return res.status(404).json({ error: 'Lead not found' });
    const result = await db.query(
      `INSERT INTO whatsapp_messages (lead_id, sent_by, direction, body) VALUES ($1,$2,$3,$4) RETURNING *`,
      [req.params.id, req.user.id, direction, msg]
    );
    res.status(201).json(result.rows[0]);
  })
);

/* ── POST /api/leads/:id/payments ──────────────────────────── */
router.post(
  '/:id/payments',
  param('id').isInt(),
  [
    body('amount').isFloat({ min: 0.01 }).withMessage('Amount must be positive'),
    body('payment_mode').optional().trim().notEmpty(),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { amount, payment_mode = 'Cash', note } = req.body;

    const lead = await db.query(`SELECT * FROM leads WHERE id = $1`, [id]);
    if (!lead.rows[0]) return res.status(404).json({ error: 'Lead not found' });

    const payment = await db.query(
      `INSERT INTO fee_payments (lead_id, recorded_by, amount, payment_mode, note)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [id, req.user.id, parseFloat(amount), payment_mode, note || null]
    );

    const newPaid   = parseFloat(lead.rows[0].fee_paid) + parseFloat(amount);
    const capped    = Math.min(newPaid, parseFloat(lead.rows[0].fee_total));
    const newStatus = capped >= parseFloat(lead.rows[0].fee_total) && parseFloat(lead.rows[0].fee_total) > 0
      ? 'Paid' : 'Partial';

    await db.query(
      `UPDATE leads SET fee_paid = $1, fee_status = $2 WHERE id = $3`,
      [capped, newStatus, id]
    );

    res.status(201).json(payment.rows[0]);
  })
);

module.exports = router;
