const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { body, param } = require('express-validator');
const db = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { asyncHandler, validate } = require('../middleware/errors');

router.use(authenticate);

/* GET /api/users — admin gets all, agent gets self */
router.get('/', asyncHandler(async (req, res) => {
  if (req.user.role === 'admin') {
    const result = await db.query(
      `SELECT id, username, name, email, role, is_active, created_at FROM users ORDER BY name`
    );
    return res.json(result.rows);
  }
  const result = await db.query(
    `SELECT id, username, name, email, role FROM users WHERE id = $1`, [req.user.id]
  );
  res.json(result.rows);
}));

/* GET /api/users/:id/stats — agent performance */
router.get('/:id/stats', requireAdmin, asyncHandler(async (req, res) => {
  const { id } = req.params;

  const [leads, calls, enrolled, todayCalls] = await Promise.all([
    db.query(`SELECT COUNT(*), status FROM leads WHERE assigned_to = $1 GROUP BY status`, [id]),
    db.query(`SELECT COUNT(*) FROM call_logs WHERE logged_by = $1`, [id]),
    db.query(`SELECT COUNT(*) FROM leads WHERE assigned_to = $1 AND status = 'Enrolled'`, [id]),
    db.query(`SELECT COUNT(*) FROM call_logs WHERE logged_by = $1 AND called_at::date = CURRENT_DATE`, [id]),
  ]);

  const pipeline = {};
  leads.rows.forEach((r) => { pipeline[r.status] = parseInt(r.count); });
  const totalLeads = Object.values(pipeline).reduce((a, b) => a + b, 0);

  res.json({
    pipeline,
    total_leads: totalLeads,
    total_calls: parseInt(calls.rows[0].count),
    enrolled: parseInt(enrolled.rows[0].count),
    conversion_rate: totalLeads ? Math.round(parseInt(enrolled.rows[0].count) / totalLeads * 100) : 0,
    calls_today: parseInt(todayCalls.rows[0].count),
  });
}));

/* POST /api/users — admin creates agent */
router.post(
  '/',
  requireAdmin,
  [
    body('username').trim().isLength({ min: 3 }),
    body('name').trim().notEmpty(),
    body('password').isLength({ min: 6 }),
    body('role').optional().isIn(['admin','agent']),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const { username, name, email, password, role = 'agent' } = req.body;
    const hashed = await bcrypt.hash(password, 10);
    const result = await db.query(
      `INSERT INTO users (username, name, email, password, role) VALUES ($1,$2,$3,$4,$5)
       RETURNING id, username, name, email, role, created_at`,
      [username.toLowerCase(), name, email || null, hashed, role]
    );
    res.status(201).json(result.rows[0]);
  })
);

/* PATCH /api/users/:id */
router.patch('/:id', param('id').isInt(), validate, asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (req.user.role !== 'admin' && req.user.id !== parseInt(id)) {
    return res.status(403).json({ error: 'Access denied' });
  }
  const allowed = ['name', 'email', 'is_active'];
  if (req.user.role === 'admin') allowed.push('role');

  const updates = [];
  const values = [];
  allowed.forEach((f) => {
    if (req.body[f] !== undefined) { values.push(req.body[f]); updates.push(`${f} = $${values.length}`); }
  });
  if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });
  values.push(id);

  const result = await db.query(
    `UPDATE users SET ${updates.join(', ')} WHERE id = $${values.length}
     RETURNING id, username, name, email, role, is_active`,
    values
  );
  res.json(result.rows[0]);
}));

module.exports = router;
