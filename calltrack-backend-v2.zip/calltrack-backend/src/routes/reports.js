const router = require('express').Router();
const { query: qv } = require('express-validator');
const db = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { asyncHandler, validate } = require('../middleware/errors');

router.use(authenticate, requireAdmin);

/* ── GET /api/reports/overview ─────────────────────────────
   FIX: All date params now use parameterised queries — no raw
   string interpolation from user input (was SQL-injectable).
─────────────────────────────────────────────────────────── */
router.get(
  '/overview',
  [
    qv('from').optional().isDate().withMessage('from must be YYYY-MM-DD'),
    qv('to').optional().isDate().withMessage('to must be YYYY-MM-DD'),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const { from, to } = req.query;
    const hasDateRange = from && to;

    // Parameterised date conditions — never interpolated
    const leadDateWhere  = hasDateRange ? 'AND l.created_at BETWEEN $1 AND $2'   : '';
    const callDateWhere  = hasDateRange ? 'AND cl.called_at BETWEEN $1 AND $2'   : '';
    const dateParams     = hasDateRange ? [from, to] : [];

    const [pipeline, bySource, byIndustry, byAgent, fees, callDisp] = await Promise.all([
      db.query(
        `SELECT status, COUNT(*) AS count
         FROM leads l WHERE 1=1 ${leadDateWhere}
         GROUP BY status ORDER BY count DESC`,
        dateParams
      ),
      db.query(
        `SELECT source, COUNT(*) AS count
         FROM leads l WHERE 1=1 ${leadDateWhere}
         GROUP BY source ORDER BY count DESC`,
        dateParams
      ),
      db.query(
        `SELECT industry, COUNT(*) AS count
         FROM leads l WHERE 1=1 ${leadDateWhere}
         GROUP BY industry ORDER BY count DESC`,
        dateParams
      ),
      db.query(
        `SELECT
           u.id, u.name, u.username,
           COUNT(DISTINCT l.id)  AS total_leads,
           COUNT(DISTINCT l.id) FILTER (WHERE l.status = 'Enrolled') AS enrolled,
           COUNT(DISTINCT cl.id) AS total_calls,
           COALESCE(SUM(DISTINCT l.fee_paid), 0) AS fees_collected
         FROM users u
         LEFT JOIN leads l
           ON l.assigned_to = u.id ${hasDateRange ? 'AND l.created_at BETWEEN $1 AND $2' : ''}
         LEFT JOIN call_logs cl
           ON cl.logged_by = u.id ${hasDateRange ? 'AND cl.called_at BETWEEN $1 AND $2' : ''}
         WHERE u.role = 'agent'
         GROUP BY u.id, u.name, u.username
         ORDER BY total_leads DESC`,
        dateParams
      ),
      db.query(
        `SELECT
           COALESCE(SUM(fee_total), 0) AS expected,
           COALESCE(SUM(fee_paid),  0) AS collected
         FROM leads l WHERE 1=1 ${leadDateWhere}`,
        dateParams
      ),
      db.query(
        `SELECT cl.disposition, COUNT(*) AS count
         FROM call_logs cl
         JOIN leads l ON l.id = cl.lead_id
         WHERE 1=1 ${callDateWhere}
         GROUP BY cl.disposition ORDER BY count DESC`,
        dateParams
      ),
    ]);

    res.json({
      pipeline:         pipeline.rows,
      by_source:        bySource.rows,
      by_industry:      byIndustry.rows,
      by_agent:         byAgent.rows,
      fees:             fees.rows[0],
      call_dispositions: callDisp.rows,
    });
  })
);

/* ── GET /api/reports/followups ────────────────────────────── */
router.get('/followups', asyncHandler(async (req, res) => {
  const base = `
    SELECT l.id, l.name, l.phone, l.course, l.status,
           l.followup_at, l.followup_note, u.name AS agent_name
    FROM leads l
    LEFT JOIN users u ON u.id = l.assigned_to
  `;
  const [overdue, today, upcoming] = await Promise.all([
    db.query(`${base} WHERE l.followup_at < CURRENT_DATE AND l.followup_at IS NOT NULL ORDER BY l.followup_at ASC  LIMIT 200`),
    db.query(`${base} WHERE l.followup_at = CURRENT_DATE                                ORDER BY l.name ASC`),
    db.query(`${base} WHERE l.followup_at > CURRENT_DATE                                ORDER BY l.followup_at ASC LIMIT 200`),
  ]);
  res.json({ overdue: overdue.rows, today: today.rows, upcoming: upcoming.rows });
}));

/* ── GET /api/reports/fees ─────────────────────────────────── */
router.get('/fees', asyncHandler(async (req, res) => {
  const result = await db.query(`
    SELECT
      l.id, l.name, l.industry,
      l.fee_total, l.fee_paid,
      l.fee_total - l.fee_paid AS balance,
      l.fee_status, l.fee_due_date,
      u.name AS agent_name,
      COALESCE(
        json_agg(fp ORDER BY fp.paid_at DESC) FILTER (WHERE fp.id IS NOT NULL),
        '[]'
      ) AS payments
    FROM leads l
    LEFT JOIN users u  ON u.id  = l.assigned_to
    LEFT JOIN fee_payments fp ON fp.lead_id = l.id
    WHERE l.fee_total > 0
    GROUP BY l.id, u.name
    ORDER BY l.fee_status, l.name
  `);
  res.json(result.rows);
}));

module.exports = router;
