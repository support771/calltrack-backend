const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body } = require('express-validator');
const { query } = require('../db');
const { authenticate } = require('../middleware/auth');
const { asyncHandler, validate } = require('../middleware/errors');

/* POST /api/auth/login */
router.post(
  '/login',
  [
    body('username').trim().notEmpty().withMessage('Username is required'),
    body('password').notEmpty().withMessage('Password is required'),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const { username, password } = req.body;

    const result = await query(
      `SELECT id, username, name, email, role, password, is_active
       FROM users WHERE username = $1`,
      [username.toLowerCase()]
    );
    const user = result.rows[0];

    if (!user || !user.is_active) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const payload = {
      id: user.id,
      username: user.username,
      name: user.name,
      role: user.role,
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    });

    res.json({
      token,
      user: { id: user.id, username: user.username, name: user.name, email: user.email, role: user.role },
    });
  })
);

/* GET /api/auth/me */
router.get('/me', authenticate, asyncHandler(async (req, res) => {
  const result = await query(
    `SELECT id, username, name, email, role, created_at FROM users WHERE id = $1`,
    [req.user.id]
  );
  if (!result.rows[0]) return res.status(404).json({ error: 'User not found' });
  res.json(result.rows[0]);
}));

/* POST /api/auth/change-password */
router.post(
  '/change-password',
  authenticate,
  [
    body('current_password').notEmpty(),
    body('new_password').isLength({ min: 6 }).withMessage('Min 6 characters'),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const { current_password, new_password } = req.body;
    const result = await query(`SELECT password FROM users WHERE id = $1`, [req.user.id]);
    const valid = await bcrypt.compare(current_password, result.rows[0].password);
    if (!valid) return res.status(400).json({ error: 'Current password is incorrect' });

    const hashed = await bcrypt.hash(new_password, 10);
    await query(`UPDATE users SET password = $1 WHERE id = $2`, [hashed, req.user.id]);
    res.json({ message: 'Password updated' });
  })
);

module.exports = router;
